package net.glxn.qrgen.core.scheme;

/**
 *
 */
public class BizCard extends Schema {

	/**
	 * 
	 */
	public BizCard() {
		super();
	}

	@Override
	public String toString() {
		return generateString();
	}

	@Override
	public Schema parseSchema(String code) {
		// TODO implement
		return null;
	}

	@Override
	public String generateString() {
		// TODO implement
		return "NOT IMPLEMENTED!!!";
	}

}
