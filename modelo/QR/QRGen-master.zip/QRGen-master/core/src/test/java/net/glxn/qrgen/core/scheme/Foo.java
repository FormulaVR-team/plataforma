package net.glxn.qrgen.core.scheme;

public class Foo extends Schema {

	@Override
	public Schema parseSchema(String code) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String generateString() {
		// TODO Auto-generated method stub
		return null;
	}

}
