package net.glxn.qrgen.core.scheme;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ICalTest {

	@Test
	public void test() {
		assertTrue(true);
	}

}
